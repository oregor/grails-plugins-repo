package com.oregor.auth

import org.apache.commons.lang.builder.HashCodeBuilder

class UserTenant implements Serializable {

	User user
	Tenant tenant

	boolean equals(other) {
		if (!(other instanceof UserTenant)) {
			return false
		}

		other.user?.id == user?.id &&
			other.tenant?.id == tenant?.id
	}

	int hashCode() {
		def builder = new HashCodeBuilder()
		if (user) builder.append(user.id)
		if (tenant) builder.append(tenant.id)
		builder.toHashCode()
	}

	static UserTenant get(long userId) {
		find 'from UserTenant where user.id=:userId',
			[userId: userId]
	}

	static UserTenant get(long userId, long tenantId) {
		find 'from UserTenant where user.id=:userId and tenant.id=:tenantId',
			[userId: userId, tenantId: tenantId]
	}

	static UserTenant create(User user, Tenant tenant, boolean flush = false) {
		new UserTenant(user: user, tenant: tenant).save(flush: flush, insert: true)
	}

	static boolean remove(User user, Tenant tenant, boolean flush = false) {
		UserTenant instance = UserTenant.findByUserAndTenant(user, tenant)
		if (!instance) {
			return false
		}

		instance.delete(flush: flush)
		true
	}

	static void removeAll(User user) {
		executeUpdate 'DELETE FROM UserTenant WHERE user=:user', [user: user]
	}

	static void removeAll(Tenant tenant) {
		executeUpdate 'DELETE FROM UserTenant WHERE tenant=:tenant', [tenant: tenant]
	}

	static mapping = {
		id composite: ['tenant', 'user']
		version false
	}
	
}
