/**
 * 
 */
/**
 * @author tsakostas
 *
 */
package com.oregor.auth;