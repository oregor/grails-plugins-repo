package com.oregor.auth

class Tenant {

	String name
	
    static constraints = {
 
	}
}
