package com.oregor.auth

class User {

	transient springSecurityService

	String fullName
	String username
	String password
	boolean enabled
	boolean accountExpired
	boolean accountLocked
	boolean passwordExpired

	static constraints = {
		fullName nullable: false, blank: false
		username nullable: false, blank: false, unique: true
		password nullable: false, blank: false
	}

	static mapping = {
		password column: '`password`'
	}

	Set<Role> getAuthorities() {
		UserRole.findAllByUser(this).collect { it.role } as Set
	}

	def beforeInsert() {
		encodePassword()
	}

	def beforeUpdate() {
		if(password.length() < 50) {
			// if (isDirty('password')) {
				encodePassword()
			//}
		}
	}

	protected void encodePassword() {
		password = springSecurityService.encodePassword(password)
	}
	
	String toString() { "$username" }
}
