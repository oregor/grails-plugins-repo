package oregor.authentication

class SignUpController {

    def index() { }
	
	def submit() {
		println "submit called"	
		render "submit called: " + params.username + " / " + params.password	
	}
}
